C0FHIRTS ;VAMC/JS-FHIR SUITE TESTER ; 24-JAN-2026
 ;;1.0;C0FHIR PROJECT;;Jan 24, 2026;Build 1
 Q
EN ; Main entry point for interactive testing
 N DFN,ENCPTR,RES,DIR,X,Y,DTOUT,DUOUT,DIRUT,DIROUT
 ;
 W !!,"--- C0FHIR Suite Interactive Tester ---",!
 ;
 ; 1. Prompt for Patient (File #2: PATIENT)
 S DIR(0)="PO^2:AEMQ"
 S DIR("A")="Select Patient"
 D ^DIR K DIR
 I $D(DIRUT) W !,"Test Cancelled." Q
 S DFN=+Y
 ;
 ; 2. Prompt for Encounter (File #409.68: OUTPATIENT ENCOUNTER)
 ; Filter: Only show encounters belonging to the selected DFN
 S DIR(0)="PO^409.68:AEMQ"
 S DIR("A")="Select Encounter for "_$P(Y,U,2)
 S DIR("S")="I $P(^(0),U,2)=DFN"
 D ^DIR K DIR
 I $D(DIRUT) W !,"Test Cancelled." Q
 S ENCPTR=+Y
 ;
 W !!,"Generating FHIR Bundle for DFN: "_DFN_" / Encounter: "_ENCPTR_"..."
 ;
 ; 3. Execute the Aggregator
 D GENFULL^C0FHIRGF(.RES,DFN,ENCPTR)
 ;
 ; 4. Validate and Inspect Results
 I '$D(RES) W !,"FAIL: No results returned. Check error trap (^%ZTER)." Q
 ;
 W !,"SUCCESS: JSON Bundle Created."
 D VERIFY ; Run routine dependency check
 ;
 ; 5. Display the first few lines of JSON
 W !!,"Preview of JSON Output:",!
 N I S I="" F  S I=$O(RES(I)) Q:I=""!(I>10)  W !,RES(I)
 W !!,"--- End of Test ---",!
 Q
 ;
VERIFY ; Internal check for necessary routines
 N R
 W !,"Checking Namespace Dependencies:"
 F R="C0FHIRGF","C0FHIRPT","C0FHIRLM","C0FHIRIM","C0FHIRVM","C0FHIRMX","C0FHIRPM","C0FHIRRX","C0FHIRNOTE","C0FHIRUTL" D
 . X "I $L($T(^"_R_")) W !,"" [OK]  ""_R E  W !,"" [!!]  MISSING: ""_R"
 Q