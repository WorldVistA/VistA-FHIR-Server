C0FHIRGF ;VAMC/JS-FHIR FULL ENCOUNTER BUNDLE ; 19-JAN-2026
 ;;1.0;C0FHIR PROJECT;;Jan 19, 2026;Build 1
 Q
GENFULL(RESULT,DFN,ENCPTR) ;RPC: C0FHIR GET FULL BUNDLE
 N BNDL,JSON,TARGET,ERR,CNT,ID,VTYPE,LOINC,RXNORM,VDT,IMMIEN,POV,VISIT,ENCID,GLB,PRCIEN
 N LRDFN,LBDT,LRI,LRIDT,TESTIEN
 S CNT=0,GLB=$NA(^TMP("C0FHIRGF",$J)) K @GLB,RESULT
 ; 1. Bundle Header
 S BNDL("resourceType")="Bundle",BNDL("type")="collection"
 ;
 ; --- SECTION 1: PATIENT DEMOGRAPHICS (File #2: PATIENT) ---
 K TARGET,ERR
 D GETS^DIQ(2,DFN_",",".01;.02;.03;.09;.63","IE","TARGET","ERR")
 I $D(ERR) D LOGERR("Patient Lookup",.ERR,.BNDL,.CNT) G EXIT
 S CNT=CNT+1,BNDL("entry",CNT,"resource","resourceType")="Patient"
 S BNDL("entry",CNT,"resource","id")=DFN
 S BNDL("entry",CNT,"resource","name",1,"text")=$G(TARGET(2,DFN_",",.01,"E")) ;NAME
 S BNDL("entry",CNT,"resource","gender")=$S($G(TARGET(2,DFN_",",.02,"I"))="M":"male",1:"female") ;SEX
 S BNDL("entry",CNT,"resource","birthDate")=$$ISO8601^C0FHIRUTL($G(TARGET(2,DFN_",",.03,"I"))) ;DOB
 S LRDFN=$G(TARGET(2,DFN_",",.63,"I")) ;LRDFN (Pointer to File #63)
 ;
 ; --- SECTION 2: ENCOUNTER (File #409.68: OUTPATIENT ENCOUNTER) ---
 S ENCID="ENC-"_ENCPTR
 K TARGET,ERR
 D GETS^DIQ(409.68,ENCPTR_",",".01;.04;.05","IE","TARGET","ERR")
 I $D(ERR) D LOGERR("Encounter Lookup",.ERR,.BNDL,.CNT) G EXIT
 S VISIT=$G(TARGET(409.68,ENCPTR_",",.05,"I")) ;VISIT (Pointer to File #9000010)
 S CNT=CNT+1,BNDL("entry",CNT,"resource","resourceType")="Encounter",BNDL("entry",CNT,"resource","id")=ENCID
 S BNDL("entry",CNT,"resource","status")="finished"
 S BNDL("entry",CNT,"resource","location",1,"location","display")=$G(TARGET(409.68,ENCPTR_",",.04,"E")) ;CLINIC
 S BNDL("entry",CNT,"resource","subject","reference")="Patient/"_DFN
 ;
 ; --- SECTION 3: VISTA LABS (File #63: LAB DATA) ---
 I LRDFN,VISIT D
 . S LBDT=$$GET1^DIQ(9000010,VISIT_",",.01,"I") Q:'LBDT  ;VISIT DATE/TIME
 . S LRIDT=9999999-LBDT,LRI=LRIDT
 . F  S LRI=$O(^LR(LRDFN,"CH",LRI)) Q:'LRI!(LRI>(LRIDT_".9999"))  D
 .. S TESTIEN=1 F  S TESTIEN=$O(^LR(LRDFN,"CH",LRI,TESTIEN)) Q:'TESTIEN  D
 ... N DATA,RESULT,UNIT,TESTNM,LABERR
 ... S DATA=$G(^LR(LRDFN,"CH",LRI,TESTIEN))
 ... S RESULT=$P(DATA,"^",1) ;LAB RESULT
 ... S UNIT=$P($P(DATA,"^",2),"!",7) ;UNITS (extracted from piece 2)
 ... S TESTNM=$$GET1^DIQ(60,TESTIEN_",",.01,"","","LABERR") ;File #60: LABORATORY TEST (.01:NAME)
 ... I $D(LABERR) Q
 ... S CNT=CNT+1,BNDL("entry",CNT,"resource","resourceType")="Observation"
 ... S BNDL("entry",CNT,"resource","category",1,"coding",1,"code")="laboratory"
 ... S BNDL("entry",CNT,"resource","code","text")=TESTNM
 ... S BNDL("entry",CNT,"resource","valueQuantity","value")=RESULT
 ... S BNDL("entry",CNT,"resource","valueQuantity","unit")=UNIT
 ... S BNDL("entry",CNT,"resource","effectiveDateTime")=$$ISO8601^C0FHIRUTL(9999999-LRI)
 ... S BNDL("entry",CNT,"resource","encounter","reference")="Encounter/"_ENCID
 ;
EXIT ; Finalize and encode to Global Array
 S BNDL("total")=CNT
 D ENCODE^XLFJSON("BNDL",GLB)
 M RESULT=@GLB
 K @GLB
 Q
 ;
LOGERR(MSG,ERR,BNDL,CNT) ; Log FileMan errors as FHIR OperationOutcome
 S CNT=CNT+1
 S BNDL("entry",CNT,"resource","resourceType")="OperationOutcome"
 S BNDL("entry",CNT,"resource","issue",1,"severity")="error"
 S BNDL("entry",CNT,"resource","issue",1,"diagnostics")="VistA FileMan Error in "_MSG_": "_$G(ERR("DIERR",1,"TEXT",1))
 Q